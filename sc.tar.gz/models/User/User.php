<?php

namespace app\models\User;

use Da\User\Model\User as BaseUser;

class User extends BaseUser;
{
    
}
